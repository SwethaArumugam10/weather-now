# React + Vite

# Weather Now 🌤️

A responsive weather application built using React that displays real-time weather for any city using the OpenWeatherMap API.

## 🌐 Live Site
[View on Netlify](https://weather-in-a-second.netlify.app/)

## 🧠 Tech Stack
- React.js (with Vite)
- OpenWeatherMap API
- CSS (responsive design)

## 📦 Features
- City search with Enter key or button
- Real-time weather: temperature, condition, humidity, wind
- Error handling for invalid cities
- Fully responsive UI

## 🧪 How I Used ChatGPT (LLM)
- Helped plan project structure
- Debugged API issues
- Helped design responsive layout and styling
- Assisted with README structure

## 🚀 How to Run Locally
```bash
npm install
npm run dev
